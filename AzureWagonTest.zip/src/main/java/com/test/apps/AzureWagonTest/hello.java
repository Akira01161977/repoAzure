package com.test.apps.AzureWagonTest;

public class hello {

	public hello(){
		System.out.println("");
	}
}
